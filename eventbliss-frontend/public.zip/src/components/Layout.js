import React, { useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import axios from "axios";

export default function Layout({ children }) {
  const [scrolled, setScrolled] = useState(false);
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [role, setRole] = useState(localStorage.getItem("role"));

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    
    if (!document.getElementById("eb-gradient-keyframes")) {
      const el = document.createElement("style");
      el.id = "eb-gradient-keyframes";
      el.innerHTML = `
        @keyframes ebGradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `;
      document.head.appendChild(el);
    }
    
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const storedToken = localStorage.getItem("token");
    const storedRole = localStorage.getItem("role");

    setToken(storedToken);
    setRole(storedRole);
    
    if (storedToken) {
      axios.defaults.headers.common["Authorization"] = `Bearer ${storedToken}`;
    } else {
      delete axios.defaults.headers.common["Authorization"];
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("name");
    
    delete axios.defaults.headers.common["Authorization"];
    
    setToken(null);
    setRole(null);
    window.location.href = "/";
  };

  return (
    <div style={styles.appContainer}>
      <header style={ scrolled ? {...styles.header, ...styles.headerScrolled} : styles.header }>
        <div style={styles.brand}>
          <Link to="/" style={{ color: "inherit", textDecoration: "none" }}>🎉 <span style={{fontWeight:800}}>EventBliss</span></Link>
        </div>

        <nav style={styles.nav}>
          <NavLink to="/" style={styles.navLink}>Home</NavLink>
          <NavLink to="/events" style={styles.navLink}>Events</NavLink>
          { (role === "admin" || role === "owner") && <NavLink to="/create" style={styles.navLink}>Create</NavLink> }
          { (role === "owner") && <NavLink to="/users" style={styles.navLink}>Users</NavLink> } {/* New link for User Management */}
          { token ? (
            <>
              <NavLink to="/profile" style={styles.navLink}>Profile</NavLink>
              <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
            </>
          ) : (
            <>
              <NavLink to="/login" style={styles.navLink}>Login</NavLink>
              <NavLink to="/register" style={styles.navLink}>Register</NavLink>
            </>
          )}
        </nav>
      </header>

      <main style={styles.main}>
        {children}
      </main>

      <div style={styles.bg} aria-hidden="true" />
    </div>
  );
}

const styles = {
  appContainer: {
    minHeight: "100vh",
    fontFamily: "'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial",
    position: "relative",
    overflowX: "hidden",
  },
  header: {
    position: "fixed",
    left: 0, right: 0, top: 0,
    zIndex: 50,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "14px 22px",
    color: "white",
    transition: "all 0.25s ease",
    background: "transparent"
  },
  headerScrolled: {
    background: "rgba(255,255,255,0.95)",
    color: "#111",
    boxShadow: "0 6px 20px rgba(0,0,0,0.08)"
  },
  brand: { fontSize: 18 },
  nav: { display: "flex", alignItems: "center", gap: 14 },
  navLink: { color: "inherit", textDecoration: "none", fontWeight: 600 },
  logoutBtn: { marginLeft: 8, padding: "8px 12px", borderRadius: 8, border: "none", background: "#ef4444", color: "white", cursor: "pointer", fontWeight:700 },
  main: { paddingTop: 92, maxWidth: 1200, margin: "0 auto", paddingLeft: 18, paddingRight: 18, minHeight: "calc(100vh - 120px)" },
  bg: {
    position: "fixed",
    inset: 0,
    zIndex: -1,
    background: "linear-gradient(270deg,#6366F1,#7C3AED,#EC4899)",
    backgroundSize: "400% 400%",
    animation: "ebGradient 14s ease infinite"
  }
};
