import React, { useState, useEffect } from "react";
import axios from "axios";
import Layout from "./Layout";
import { useNavigate } from "react-router-dom";

export default function UserManagementPage() {
  const nav = useNavigate();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          nav("/login");
          return;
        }
        
        const res = await axios.get("http://localhost:5000/api/users", {
          headers: { Authorization: `Bearer ${token}` }
        });
        setUsers(res.data);
      } catch (err) {
        console.error("Error fetching users:", err);
        setMessage(err.response?.data?.message || "Failed to load users.");
        if (err.response?.status === 403 || err.response?.status === 401) {
          nav("/events"); 
        }
      } finally {
        setLoading(false);
      }
    };
    
    const storedRole = localStorage.getItem("role");
    const storedUserId = localStorage.getItem("userId");
    setCurrentUser(storedUserId);

    if (storedRole === "owner") {
      fetchUsers();
    } else {
      nav("/events");
    }
  }, [nav]);

  const handleUpdateRole = async (userId, newRole) => {
    if (!window.confirm(`Are you sure you want to change this user's role to ${newRole}?`)) return;

    try {
      const token = localStorage.getItem("token");
      await axios.put(`http://localhost:5000/api/users/${userId}`, { role: newRole }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessage("User role updated successfully!");
      setUsers(users.map(u => u._id === userId ? { ...u, role: newRole } : u));
    } catch (err) {
      console.error(err);
      setMessage(err.response?.data?.message || "Failed to update user role.");
    }
  };

  const handleUpdateStatus = async (userId, newStatus) => {
    if (!window.confirm(`Are you sure you want to change this user's status to ${newStatus}?`)) return;

    try {
      const token = localStorage.getItem("token");
      await axios.put(`http://localhost:5000/api/users/status/${userId}`, { status: newStatus }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessage("User status updated successfully!");
      setUsers(users.map(u => u._id === userId ? { ...u, status: newStatus } : u));
    } catch (err) {
      console.error(err);
      setMessage(err.response?.data?.message || "Failed to update user status.");
    }
  };

  const handleDeleteUser = async (userId) => {
    if (!window.confirm("Are you sure you want to delete this user? This action cannot be undone.")) return;

    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:5000/api/users/${userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessage("User deleted successfully!");
      setUsers(users.filter(u => u._id !== userId));
    } catch (err) {
      console.error(err);
      setMessage(err.response?.data?.message || "Failed to delete user.");
    }
  };

  const cardStyle = {
    padding: 24,
    borderRadius: 12,
    background: "rgba(255,255,255,0.04)",
    backdropFilter: "blur(6px)",
    boxShadow: "0 6px 16px rgba(0,0,0,0.2)",
    color: "white"
  };

  const tableHeaderStyle = {
    padding: "12px",
    textAlign: "left",
    fontWeight: "bold",
    borderBottom: "1px solid rgba(255,255,255,0.1)"
  };

  const tableCellStyle = {
    padding: "12px",
    borderBottom: "1px solid rgba(255,255,255,0.05)"
  };

  const buttonStyle = {
    padding: "6px 12px",
    borderRadius: "6px",
    border: "none",
    color: "white",
    fontWeight: "bold",
    cursor: "pointer",
    marginRight: "8px"
  };

  return (
    <Layout>
      <div style={cardStyle}>
        <h2 style={{ color: "white", marginTop: 0, textAlign: "center" }}>User Management</h2>
        {message && <div style={{ color: message.includes("successful") ? "lime" : "red", textAlign: "center", marginBottom: 16 }}>{message}</div>}

        {loading ? (
          <p style={{ textAlign: "center" }}>Loading users...</p>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th style={tableHeaderStyle}>User ID</th>
                <th style={tableHeaderStyle}>Username</th>
                <th style={tableHeaderStyle}>Email</th>
                <th style={tableHeaderStyle}>Role</th>
                <th style={tableHeaderStyle}>Status</th>
                <th style={tableHeaderStyle}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user._id}>
                  <td style={tableCellStyle}>{user._id}</td>
                  <td style={tableCellStyle}>{user.username}</td>
                  <td style={tableCellStyle}>{user.email}</td>
                  <td style={tableCellStyle}>
                    <select
                      value={user.role}
                      onChange={(e) => handleUpdateRole(user._id, e.target.value)}
                      disabled={user._id === currentUser}
                      style={{ padding: "4px", borderRadius: "4px", border: "none" }}
                    >
                      <option value="user">user</option>
                      <option value="admin">admin</option>
                      <option value="owner">owner</option>
                    </select>
                  </td>
                  <td style={tableCellStyle}>
                     <select
                      value={user.status}
                      onChange={(e) => handleUpdateStatus(user._id, e.target.value)}
                      disabled={user._id === currentUser}
                      style={{ padding: "4px", borderRadius: "4px", border: "none" }}
                    >
                      <option value="active">Active</option>
                      <option value="frozen">Frozen</option>
                      <option value="blocked">Blocked</option>
                    </select>
                  </td>
                  <td style={tableCellStyle}>
                    {user._id !== currentUser && (
                      <button
                        onClick={() => handleDeleteUser(user._id)}
                        style={{ ...buttonStyle, background: "#ef4444" }}
                      >
                        Delete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </Layout>
  );
}